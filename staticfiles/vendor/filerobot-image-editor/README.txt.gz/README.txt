Filerobot Image Editor vendored assets
=====================================

Place these files (matching the version you want) in this directory:

- filerobot-image-editor.min.css
- filerobot-image-editor.min.js

You can obtain them via CDN:
  https://scaleflex.cloudimg.io/v7/plugins/filerobot-image-editor/filerobot-image-editor.min.css
  https://scaleflex.cloudimg.io/v7/plugins/filerobot-image-editor/filerobot-image-editor.min.js

After copying, the admin editor will prefer local files and only fall back to CDN if missing.

