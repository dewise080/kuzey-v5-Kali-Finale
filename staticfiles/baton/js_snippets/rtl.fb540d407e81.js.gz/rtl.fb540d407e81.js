Baton.translations = {
  unsavedChangesAlert: 'تغییرات ذخیره نشده دارید',
  uploading: 'در حال آپلود...',
  filter: 'فیلتر',
  close: 'بستن',
  save: 'ذخیره',
  search: 'جستجو',
  cannotCopyToClipboardMessage: 'امکان کپی کردن به کلیپ‌بورد وجود ندارد، لطفاً دستی این کار را انجام دهید: Ctrl+C، Enter',
  retrieveDataError: 'خطایی در بازیابی داده‌ها رخ داد',
  lightTheme: 'تم روشن',
  darkTheme: 'تم تیره',
}
